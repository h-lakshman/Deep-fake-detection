from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
    path('userRegister/',views.userRegister),
    path('login/',views.login),
    
    
    # ----------------USER
    path('userdash/',views.userdash),
    path('uploadimage/',views.uploadimage),



    # ----------------ADMIN
    path('admindash/',views.admindash),
    path('viewUsers/',views.viewUsers),
    path('deleteUser/',views.deleteUser),



]
