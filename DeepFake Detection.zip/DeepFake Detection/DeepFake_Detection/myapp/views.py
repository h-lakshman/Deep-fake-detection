from django.shortcuts import render, redirect, HttpResponse
from .models import *
from django.contrib import messages
from django.contrib.auth import authenticate
from datetime import date, datetime
from django.db.models import Q
from datetime import date as d, datetime as dt
from django.db.models import Max


def index(request):
    return render(request,'index.html')

def userRegister(request):
    if request.POST:
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        gender=request.POST['gender']
        address=request.POST['address']
        password=request.POST['password']
        
        log=Login.objects.create_user(username=email,password=password,view_password=password,is_active="1",user_type='user')
        log.save()

        reguser=User.objects.create(name=name,address=address,email=email,password=password,phone=phone,loginid=log,gender=gender)
        reguser.save()

        messages.success(request,"Registered Successfully")
        return redirect('/login')
    return render(request,'userRegister.html')


def login(request):
    if request.POST:
        email = request.POST['email']
        password = request.POST['password']
        print(email,password,"email,password")
        user = authenticate(username=email, password=password)
        if user is not None:
            if user.user_type == 'admin':
                print('admin#####')
                messages.info(request, 'Welcome to admin dash   board')
                return redirect('/admindash')
            elif user.user_type == 'user':
                request.session['uid'] = user.id
                print('member#####')
                messages.info(request, 'Welcome to Photopia')
                return redirect('/userdash')
            else:
                messages.info(request, 'Invalid')
        else:
            pass
    return render(request,'login.html')



def userdash(request):
    return render(request,'USER/userdash.html')


def uploadimage(request):
    uid=request.session.get('uid')
    uid = User.objects.get(loginid=uid)
    if request.POST:
        image = request.FILES["image"]
        img = Image.objects.create(userid=uid, image=image)
        img.save()        
        messages.info(request, 'Image uploaded successfully')
        return redirect('/userdash')
    return render(request,'USER/uploadimage.html')


def admindash(request):
    return render(request,'ADMIN/admindash.html')

def viewUsers(request):
    users = User.objects.all()
    return render(request,'ADMIN/viewUsers.html',{'users':users})

def deleteUser(request):
    id=request.GET.get('id')
    users = Login.objects.filter(id=id).delete()
    messages.info(request, 'User deleted successfully')
    return redirect('/viewUsers')




# def admin(request):
#     Login.objects.create_user(username='admin@gmail.com',password='admin',view_password='admin',user_type='admin',)
#     return HttpResponse("Welcome")

