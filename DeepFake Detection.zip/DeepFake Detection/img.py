import cv2
import numpy as np

def detect_fake_image(image_path):
    # Read the image
    img = cv2.imread(image_path)

    # Convert the image to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Compute the Laplacian variance
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()

    # Define a threshold to classify as fake or real
    threshold = 100

    # Compare the Laplacian variance with the threshold
    if laplacian_var < threshold:
        return "Fake"
    else:
        return "Real"

# Example usage
image_path = './642d4785c78bad001da8c1db.jpg'
result = detect_fake_image(image_path)
print("The image is:", result)
